import sys, os, time
from dataclasses import dataclass
from typing import List
from PyQt6 import QtCore, QtGui, QtWidgets
import pyqtgraph as pg

from config_manager import ConfigManager, AppConfig
from daq_driver import DaqDriver, DaqError
from filters import OnePoleLPF
from analog_chart import AnalogChartWindow
from digital_chart import DigitalChartWindow
from script_runner import ScriptRunner

class MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("MCC E-1608 Control")
        self.resize(1300, 800)

        # Model / state
        self.cfg = AppConfig()
        self.daq = None  # type: DaqDriver|None
        self.ai_filters = [OnePoleLPF(0.0, self.cfg.sampleRateHz) for _ in range(8)]
        self.ai_filter_enabled = [False]*8
        self.ai_hist_x = []
        self.ai_hist_y = [ [] for _ in range(8) ]
        self.do_hist_y = [ [] for _ in range(8) ]
        self.hist_max_pts = 1000
        self.time_window_s = 5.0
        self.ui_rate_hz = 50.0  # GUI update rate; not the same as sampleRateHz in config

        # UI
        self._build_menu()
        self._build_central()
        self._build_status_panes()

        # Charts
        self.analog_win = AnalogChartWindow(
            [a.name for a in self.cfg.analogs],
            [a.units for a in self.cfg.analogs],
        )
        self.analog_win.traceClicked.connect(self._on_trace_clicked)
        self.analog_win.requestScale.connect(self._on_request_scale)
        self.digital_win = DigitalChartWindow()

        # Timers
        self.loop_timer = QtCore.QTimer(self)
        self.loop_timer.timeout.connect(self._loop)
        self.loop_timer.start(int(1000/self.ui_rate_hz))

        # Script runner
        self.script = ScriptRunner(self._set_do)
        self.script.tick.connect(self._on_script_tick)

        # Apply initial config to UI
        self._apply_cfg_to_ui()

    # ---------- UI Construction ----------
    def _build_menu(self):
        menubar = self.menuBar()
        filem = menubar.addMenu("&File")
        a_load_cfg = filem.addAction("Load Config...", self._act_load_cfg)
        a_save_cfg = filem.addAction("Save Config As...", self._act_save_cfg)
        filem.addSeparator()
        a_load_script = filem.addAction("Load Script...", self._act_load_script)
        a_save_script = filem.addAction("Save Script As...", self._act_save_script)
        filem.addSeparator()
        a_quit = filem.addAction("Quit", self.close)

        viewm = menubar.addMenu("&View")
        viewm.addAction("Show Analog Charts", self.analog_win.show)
        viewm.addAction("Show Digital Chart", self.digital_win.show)

    def _build_central(self):
        cw = QtWidgets.QWidget()
        self.setCentralWidget(cw)
        layout = QtWidgets.QGridLayout(cw)

        # Left pane: DO controls
        self.do_panel = QtWidgets.QGroupBox("Digital Outputs")
        layout.addWidget(self.do_panel, 0, 0)
        gl = QtWidgets.QGridLayout(self.do_panel)
        self.do_btns = []
        self.do_chk_no = []
        self.do_chk_mom = []
        self.do_time = []
        for i in range(8):
            btn = QtWidgets.QPushButton(f"{i}: DO")
            btn.setCheckable(True)
            btn.setStyleSheet("QPushButton{background:#4caf50;color:white;} QPushButton:checked{background:#d32f2f;}")
            btn.clicked.connect(lambda checked, idx=i: self._on_do_clicked(idx, checked))
            gl.addWidget(btn, i, 0)
            self.do_btns.append(btn)

            chk_no = QtWidgets.QCheckBox("Normally Open")
            gl.addWidget(chk_no, i, 1)
            self.do_chk_no.append(chk_no)

            chk_m = QtWidgets.QCheckBox("Momentary")
            gl.addWidget(chk_m, i, 2)
            self.do_chk_mom.append(chk_m)

            sp = QtWidgets.QDoubleSpinBox()
            sp.setSuffix(" s")
            sp.setRange(0.0, 3600.0)
            sp.setDecimals(3)
            sp.setSingleStep(0.1)
            sp.setValue(0.0)
            gl.addWidget(sp, i, 3)
            self.do_time.append(sp)

        # Right pane: AO sliders + time controls + run controls
        right = QtWidgets.QGroupBox("Analog Outputs / Timebase / Script")
        layout.addWidget(right, 0, 1)
        rgl = QtWidgets.QGridLayout(right)

        # AO sliders
        self.ao_sliders = []
        self.ao_labels = []
        for i in range(2):
            lab = QtWidgets.QLabel(f"AO{i}: 0.00 V")
            rgl.addWidget(lab, i*2, 0, 1, 2)
            s = QtWidgets.QSlider(QtCore.Qt.Orientation.Horizontal)
            s.setRange(-1000, 1000) # map to -10..10 V; we'll clamp by config
            s.valueChanged.connect(lambda v, idx=i: self._on_ao_slider(idx, v))
            rgl.addWidget(s, i*2+1, 0, 1, 2)
            self.ao_labels.append(lab)
            self.ao_sliders.append(s)

        # Time axis
        rgl.addWidget(QtWidgets.QLabel("Time window (s)"), 4, 0)
        self.time_spin = QtWidgets.QDoubleSpinBox()
        self.time_spin.setRange(0.01, 10.0)
        self.time_spin.setDecimals(3)
        self.time_spin.setSingleStep(0.01)
        self.time_spin.setValue(self.time_window_s)
        self.time_spin.valueChanged.connect(self._on_time_window)
        rgl.addWidget(self.time_spin, 4, 1)

        # Connection + Script controls
        self.btn_connect = QtWidgets.QPushButton("Connect")
        self.btn_connect.clicked.connect(self._act_connect)
        rgl.addWidget(self.btn_connect, 5, 0)

        self.btn_run = QtWidgets.QPushButton("Run Script")
        self.btn_run.clicked.connect(self._act_run_script)
        rgl.addWidget(self.btn_run, 6, 0)

        self.btn_stop = QtWidgets.QPushButton("Stop/Pause Script")
        self.btn_stop.clicked.connect(self._act_stop_script)
        rgl.addWidget(self.btn_stop, 6, 1)

        self.btn_reset = QtWidgets.QPushButton("Reset Script")
        self.btn_reset.clicked.connect(self._act_reset_script)
        rgl.addWidget(self.btn_reset, 7, 0)

    def _build_status_panes(self):
        # Bottom panes: Tx and Rx/Debug
        dock_tx = QtWidgets.QDockWidget("Sent (Tx)", self)
        dock_rx = QtWidgets.QDockWidget("Received / Debug (Rx)", self)
        self.addDockWidget(QtCore.Qt.DockWidgetArea.BottomDockWidgetArea, dock_tx)
        self.addDockWidget(QtCore.Qt.DockWidgetArea.BottomDockWidgetArea, dock_rx)

        self.tx_text = QtWidgets.QPlainTextEdit()
        self.tx_text.setReadOnly(True)
        self.rx_text = QtWidgets.QPlainTextEdit()
        self.rx_text.setReadOnly(True)
        dock_tx.setWidget(self.tx_text)
        dock_rx.setWidget(self.rx_text)

    # ---------- Logging ----------
    def log_tx(self, msg: str):
        self.tx_text.appendPlainText(msg)

    def log_rx(self, msg: str):
        self.rx_text.appendPlainText(msg)

    # ---------- Config ----------
    def _apply_cfg_to_ui(self):
        # Names and DO config
        for i in range(8):
            self.do_btns[i].setText(f"{i}: {self.cfg.digitalOutputs[i].name}")
            self.do_chk_no[i].setChecked(self.cfg.digitalOutputs[i].normallyOpen)
            self.do_chk_mom[i].setChecked(self.cfg.digitalOutputs[i].momentary)
            self.do_time[i].setValue(self.cfg.digitalOutputs[i].actuationTime)

        # AO sliders
        for i in range(2):
            a = self.cfg.analogOutputs[i]
            # Clamp to device limits
            mn = max(-10.0, min(10.0, a.minV))
            mx = max(-10.0, min(10.0, a.maxV))
            if mn > mx:
                mn, mx = mx, mn
            self.ao_sliders[i].setMinimum(int(mn*100))
            self.ao_sliders[i].setMaximum(int(mx*100))
            self.ao_sliders[i].setValue(int(a.startupV*100))
            self.ao_labels[i].setText(f"AO{i}: {a.startupV:.2f} V ({a.name})")

        # Filters + labels
        for i in range(8):
            self.ai_filters[i].set_fs(self.ui_rate_hz)
            self.ai_filters[i].set_cutoff(self.cfg.analogs[i].cutoffHz)
            self.ai_filter_enabled[i] = (self.cfg.analogs[i].cutoffHz > 0.0)

        # Chart titles
        self.analog_win.setWindowTitle("Analog Inputs — " + ", ".join([a.name for a in self.cfg.analogs]))

    # ---------- Actions ----------
    def _act_load_cfg(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(self, "Load config.json", "", "JSON (*.json)")
        if not path:
            return
        self.cfg = ConfigManager.load(path)
        self._apply_cfg_to_ui()
        self.log_rx(f"Loaded config: {path}")

    def _act_save_cfg(self):
        path, _ = QtWidgets.QFileDialog.getSaveFileName(self, "Save config.json", "config.json", "JSON (*.json)")
        if not path:
            return
        # Pull UI back into cfg
        for i in range(8):
            self.cfg.digitalOutputs[i].normallyOpen = self.do_chk_no[i].isChecked()
            self.cfg.digitalOutputs[i].momentary = self.do_chk_mom[i].isChecked()
            self.cfg.digitalOutputs[i].actuationTime = float(self.do_time[i].value())
        ConfigManager.save(path, self.cfg)
        self.log_rx(f"Saved config: {path}")

    def _act_load_script(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(self, "Load script.json", "", "JSON (*.json)")
        if not path:
            return
        try:
            self.script.load_script(path)
            self.log_rx(f"Loaded script: {path}")
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "Script error", str(e))

    def _act_save_script(self):
        path, _ = QtWidgets.QFileDialog.getSaveFileName(self, "Save script.json", "script.json", "JSON (*.json)")
        if not path:
            return
        # For now we save the last loaded events; a full editor could be added later
        try:
            # No direct access to script internals here; stub file
            with open(path, "w", encoding="utf-8") as f:
                f.write("[]\n")
            self.log_rx(f"Saved (stub) script: {path}")
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "Save error", str(e))

    def _act_connect(self):
        if self.daq and self.daq.connected:
            self.daq.disconnect()
            self.daq = None
            self.btn_connect.setText("Connect")
            return
        try:
            self.daq = DaqDriver(self.cfg.boardNum, self.log_tx, self.log_rx)
            self.daq.connect()
            self.btn_connect.setText("Disconnect")
            # Apply AO startup values
            for i in range(2):
                self._apply_ao_slider(i)
        except DaqError as e:
            QtWidgets.QMessageBox.critical(self, "DAQ error", str(e))

    def _act_run_script(self):
        self.script.run()
        self.log_rx("Script: RUN" )

    def _act_stop_script(self):
        self.script.stop()
        self.log_rx("Script: STOP/PAUSE" )

    def _act_reset_script(self):
        self.script.reset()
        self.log_rx("Script: RESET" )

    # ---------- Callbacks ----------
    def _on_time_window(self, v):
        self.time_window_s = float(v)

    def _on_trace_clicked(self, idx):
        pass  # handled in chart window

    def _on_request_scale(self, idx):
        # Ask user: Auto or Fixed
        m = QtWidgets.QMessageBox(self)
        m.setWindowTitle(f"Scale AI{idx}")
        m.setText("Choose scaling for this trace:")
        auto_btn = m.addButton("Auto-scale", QtWidgets.QMessageBox.ButtonRole.AcceptRole)
        fixed_btn = m.addButton("Set min/max...", QtWidgets.QMessageBox.ButtonRole.ActionRole)
        cancel_btn = m.addButton(QtWidgets.QMessageBox.StandardButton.Cancel)
        m.exec()
        if m.clickedButton() == auto_btn:
            self.analog_win.autoscale(idx)
        elif m.clickedButton() == fixed_btn:
            mn, ok1 = QtWidgets.QInputDialog.getDouble(self, "Y min", "Enter Y min:", 0.0, -1e9, 1e9, 6)
            if not ok1: return
            mx, ok2 = QtWidgets.QInputDialog.getDouble(self, "Y max", "Enter Y max:", 1.0, -1e9, 1e9, 6)
            if not ok2: return
            if mx < mn: mn, mx = mx, mn
            self.analog_win.set_fixed_scale(idx, mn, mx)

    def _on_ao_slider(self, idx, raw_val):
        # Raw slider range maps to -10..+10 V; clamp to config min/max
        v = 0.01 * float(raw_val)
        a = self.cfg.analogOutputs[idx]
        v = max(max(-10.0, a.minV), min(min(10.0, a.maxV), v))
        self.ao_labels[idx].setText(f"AO{idx}: {v:.2f} V ({a.name})")
        if self.daq and self.daq.connected:
            self.daq.set_ao_volts(idx, v)

    def _apply_ao_slider(self, idx):
        # Push current slider to hardware (used at connect)
        raw_val = self.ao_sliders[idx].value()
        self._on_ao_slider(idx, raw_val)

    def _on_do_clicked(self, idx, checked):
        # Determine logical active state respecting normallyOpen
        no = self.do_chk_no[idx].isChecked()
        momentary = self.do_chk_mom[idx].isChecked()
        act_time = float(self.do_time[idx].value())

        # UI button checked == "activated"; map to logical line state
        # normallyOpen True: active -> closed (1); False: active -> open(0) depending on your wiring.
        # Here we make active=True map to bit=1, but invertable as needed by NO flag:
        bit_state = bool(checked) if no else not bool(checked)

        if self.daq and self.daq.connected:
            self._set_do(idx, bit_state)

        if momentary or act_time > 0.0:
            dur_ms = int(max(0.0, act_time) * 1000)
            QtCore.QTimer.singleShot(dur_ms if dur_ms > 0 else 200, lambda: self._release_do(idx, no))

    def _release_do(self, idx, normally_open: bool):
        # Return to "not activated" UI state
        self.do_btns[idx].setChecked(False)
        # Restore line accordingly
        bit_state = False if normally_open else True
        if self.daq and self.daq.connected:
            self._set_do(idx, bit_state)

    def _set_do(self, idx, state: bool):
        # Set hardware bit and log; update digital-history record
        if self.daq and self.daq.connected:
            try:
                self.daq.set_do_bit(idx, state)
            except Exception as e:
                self.log_rx(f"DO error: {e}")

    def _on_script_tick(self, t, relays):
        # Update UI button state to reflect script (without firing handlers)
        for i, st in enumerate(relays[:8]):
            blk = self.do_btns[i].blockSignals(True)
            self.do_btns[i].setChecked(bool(st))
            self.do_btns[i].blockSignals(blk)

    # ---------- Main Loop ----------
    def _loop(self):
        # Read all 8 AI channels (software paced); apply slope/offset/filter
        now = time.perf_counter()
        if not self.ai_hist_x or (now - self.ai_hist_x[-1]) > 0.5:
            # Prune history by time window occasionally
            self._prune_history(now)

        yvals = []
        if self.daq and self.daq.connected:
            try:
                for i in range(8):
                    v = self.daq.read_ai_volts(i)
                    a = self.cfg.analogs[i]
                    v_cal = v * a.slope + a.offset
                    if self.ai_filter_enabled[i] and a.cutoffHz > 0.0:
                        self.ai_filters[i].set_fs(self.ui_rate_hz)  # keep in sync
                        v_cal = self.ai_filters[i].process(v_cal)
                    yvals.append(v_cal)
            except Exception as e:
                self.log_rx(f"AI read error: {e}")
                yvals = [0.0]*8
        else:
            yvals = [0.0]*8

        self.ai_hist_x.append(now)
        for i in range(8):
            self.ai_hist_y[i].append(yvals[i])

        # Build x axis relative in seconds
        t0 = self.ai_hist_x[0] if self.ai_hist_x else now
        x = [t - t0 for t in self.ai_hist_x]
        # Limit view to time_window_s
        x_cut, ys_cut = self._tail_by_time(x, self.ai_hist_y, self.time_window_s)
        self.analog_win.set_data(x_cut, ys_cut)

        # Digital history: show current button states as 0/1
        do_states = [1 if self.do_btns[i].isChecked() else 0 for i in range(8)]
        for i in range(8):
            self.do_hist_y[i].append(do_states[i])
            # keep same length as ai_hist_x
            if len(self.do_hist_y[i]) > len(self.ai_hist_x):
                self.do_hist_y[i] = self.do_hist_y[i][-len(self.ai_hist_x):]

        _, do_cut = self._tail_by_time(x, self.do_hist_y, self.time_window_s)
        self.digital_win.set_data(x_cut, do_cut)

    def _prune_history(self, now):
        # Keep a maximum of e.g., 10 s worth of points at ui_rate_hz
        max_pts = int(self.ui_rate_hz * 12)
        if len(self.ai_hist_x) > max_pts:
            trim = len(self.ai_hist_x) - max_pts
            self.ai_hist_x = self.ai_hist_x[trim:]
            for i in range(8):
                self.ai_hist_y[i] = self.ai_hist_y[i][trim:]
                self.do_hist_y[i] = self.do_hist_y[i][trim:]

    @staticmethod
    def _tail_by_time(x, ys, window_s):
        if not x:
            return [], [ [] for _ in ys ]
        t_end = x[-1]
        t_start = t_end - window_s
        # find first index >= t_start
        start_idx = 0
        for i, xv in enumerate(x):
            if xv >= t_start:
                start_idx = i
                break
        x_cut = x[start_idx:]
        ys_cut = [ y[start_idx:] for y in ys ]
        return x_cut, ys_cut

def main():
    app = QtWidgets.QApplication(sys.argv)
    w = MainWindow()
    w.show()
    return app.exec()

if __name__ == "__main__":
    raise SystemExit(main())
