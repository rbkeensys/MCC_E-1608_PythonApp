from PyQt6 import QtWidgets
import pyqtgraph as pg
import numpy as np

class DigitalChartWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Digital Outputs")
        cw = QtWidgets.QWidget()
        self.setCentralWidget(cw)
        self.layout = QtWidgets.QVBoxLayout(cw)
        self.plot = pg.PlotWidget()
        self.plot.showGrid(x=True, y=True, alpha=0.2)
        self.layout.addWidget(self.plot)
        self.curves = [self.plot.plot([], [], stepMode=True, pen=pg.mkPen(width=2)) for _ in range(8)]
        self.offsets = np.arange(8)[::-1]  # 7..0 -> top to bottom
        self.plot.setLabel('left', 'DO7..DO0')
        self.plot.setLabel('bottom', 'Time (s)')

    def set_data(self, x, states_0_1_history):
        # states_0_1_history: list of 8 arrays of 0/1
        for i in range(8):
            y = states_0_1_history[i] + self.offsets[i]
            self.curves[i].setData(x, y)
