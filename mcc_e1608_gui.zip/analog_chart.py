from PyQt6 import QtCore, QtWidgets
import pyqtgraph as pg

class AnalogChartWindow(QtWidgets.QMainWindow):
    traceClicked = QtCore.pyqtSignal(int)  # index
    requestScale = QtCore.pyqtSignal(int)  # index

    def __init__(self, names, units):
        super().__init__()
        self.setWindowTitle("Analog Inputs")
        self._names = names
        self._units = units
        cw = QtWidgets.QWidget()
        self.setCentralWidget(cw)
        self.layout = QtWidgets.QGridLayout(cw)
        self.plots = []
        self.curves = []
        self.data_x = None
        self.data_y = [None]*len(names)
        self.enlarged_idx = None

        for i, nm in enumerate(names):
            plt = pg.PlotWidget()
            plt.setMinimumHeight(80)
            plt.showGrid(x=True, y=True, alpha=0.2)
            plt.enableAutoRange(axis=pg.ViewBox.YAxis, enable=True)
            self.layout.addWidget(plt, i, 0)
            curve = plt.plot([], [], pen=pg.mkPen(width=2), name=nm, clickable=True)
            curve.curve.setClickable(True)
            curve.sigClicked.connect(lambda c, idx=i: self._on_curve_clicked(idx))
            self.plots.append(plt)
            self.curves.append(curve)

    def _on_curve_clicked(self, idx):
        # Left-click: enlarge and offer scale dialog
        self.toggle_enlarge(idx)
        self.requestScale.emit(idx)

    def toggle_enlarge(self, idx):
        if self.enlarged_idx == idx:
            # restore
            for r in range(len(self.plots)):
                self.layout.setRowStretch(r, 1)
            self.enlarged_idx = None
        else:
            for r in range(len(self.plots)):
                self.layout.setRowStretch(r, 1 if r != idx else 3)
            self.enlarged_idx = idx

    def set_data(self, x, ys):
        self.data_x = x
        for i, y in enumerate(ys):
            self.data_y[i] = y
            self.curves[i].setData(x, y)

    def autoscale(self, idx):
        self.plots[idx].enableAutoRange(axis=pg.ViewBox.YAxis, enable=True)

    def set_fixed_scale(self, idx, ymin, ymax):
        vb = self.plots[idx].getViewBox()
        vb.enableAutoRange(axis=pg.ViewBox.YAxis, enable=False)
        vb.setYRange(float(ymin), float(ymax), padding=0.0)
