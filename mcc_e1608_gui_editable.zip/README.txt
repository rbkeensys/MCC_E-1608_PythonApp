See main.py. Open charts via View menu. Edit Config/Script via File menu.
